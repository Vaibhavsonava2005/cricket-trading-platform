const axios = require('axios');
const db = require('../config/database');

class CricketDataService {
    constructor() {
        this.baseURL = 'https://api.cricapi.com/v1';
        this.apiKey = process.env.CRICKET_API_KEY || 'demo_key';
        this.updateInterval = 10000; // 10 seconds
    }

    // Fetch current live matches
    async getLiveMatches() {
        try {
            // Using CricAPI as primary source
            const response = await axios.get(`${this.baseURL}/currentMatches`, {
                params: {
                    apikey: this.apiKey,
                    offset: 0
                }
            });

            if (response.data && response.data.data) {
                return response.data.data.filter(match => 
                    match.matchType === 'odi' || 
                    match.matchType === 't20' || 
                    match.matchType === 'test' ||
                    match.matchType === 't10'
                );
            }

            return [];
        } catch (error) {
            console.error('Error fetching live matches:', error.message);
            return this.getMockLiveMatches();
        }
    }

    // Get match details by ID
    async getMatchDetails(matchId) {
        try {
            const response = await axios.get(`${this.baseURL}/match_info`, {
                params: {
                    apikey: this.apiKey,
                    id: matchId
                }
            });

            return response.data.data;
        } catch (error) {
            console.error('Error fetching match details:', error.message);
            return this.getMockMatchDetails(matchId);
        }
    }

    // Get match scorecard
    async getMatchScorecard(matchId) {
        try {
            const response = await axios.get(`${this.baseURL}/match_scorecard`, {
                params: {
                    apikey: this.apiKey,
                    id: matchId
                }
            });

            return response.data.data;
        } catch (error) {
            console.error('Error fetching scorecard:', error.message);
            return null;
        }
    }

    // Cache match data in database
    async cacheMatchData(matchId, matchData, sportType = 'cricket') {
        try {
            await db.query(`
                INSERT INTO matches_cache (match_id, sport_type, match_data, last_updated)
                VALUES ($1, $2, $3, CURRENT_TIMESTAMP)
                ON CONFLICT (match_id) 
                DO UPDATE SET match_data = $3, last_updated = CURRENT_TIMESTAMP
            `, [matchId, sportType, JSON.stringify(matchData)]);
        } catch (error) {
            console.error('Error caching match data:', error.message);
        }
    }

    // Get cached match data
    async getCachedMatchData(matchId) {
        try {
            const result = await db.query(
                'SELECT match_data FROM matches_cache WHERE match_id = $1',
                [matchId]
            );
            
            if (result.rows.length > 0) {
                return result.rows[0].match_data;
            }
            return null;
        } catch (error) {
            console.error('Error getting cached match data:', error.message);
            return null;
        }
    }

    // Mock data for testing when API is unavailable
    getMockLiveMatches() {
        return [
            {
                id: 'ipl_2026_rr_vs_csk',
                name: 'Rajasthan Royals vs Chennai Super Kings',
                matchType: 't20',
                status: 'Live',
                venue: 'Sawai Mansingh Stadium, Jaipur',
                date: new Date().toISOString(),
                dateTimeGMT: new Date().toISOString(),
                teams: ['Rajasthan Royals', 'Chennai Super Kings'],
                teamInfo: [
                    { name: 'Rajasthan Royals', shortname: 'RR', img: '' },
                    { name: 'Chennai Super Kings', shortname: 'CSK', img: '' }
                ],
                score: [
                    { r: 165, w: 4, o: 18.2, inning: 'Rajasthan Royals Inning 1' },
                    { r: 142, w: 6, o: 15.3, inning: 'Chennai Super Kings Inning 1' }
                ],
                series_id: 'ipl-2026',
                fantasyEnabled: true,
                bbbEnabled: true,
                hasSquad: true,
                matchStarted: true,
                matchEnded: false
            }
        ];
    }

    getMockMatchDetails(matchId) {
        return {
            id: matchId,
            name: 'Rajasthan Royals vs Chennai Super Kings',
            matchType: 't20',
            status: 'Live',
            venue: 'Sawai Mansingh Stadium, Jaipur',
            date: new Date().toISOString(),
            teams: ['Rajasthan Royals', 'Chennai Super Kings'],
            score: [
                { r: 165, w: 4, o: 18.2, inning: 'Rajasthan Royals Inning 1' },
                { r: 142, w: 6, o: 15.3, inning: 'Chennai Super Kings Inning 1' }
            ],
            tossWinner: 'Rajasthan Royals',
            tossChoice: 'bat',
            matchWinner: null,
            matchStarted: true,
            matchEnded: false
        };
    }

    // Generate betting odds based on match situation
    generateOdds(matchData) {
        const team1 = matchData.teams[0];
        const team2 = matchData.teams[1];
        
        // Simple odds generation (in production, this would be more sophisticated)
        const baseOdds = {
            matchOdds: {
                [team1]: { back: 2.10, lay: 2.12 },
                [team2]: { back: 1.82, lay: 1.84 }
            },
            bookmaker: {
                [team1]: { back: 111, lay: 120 },
                [team2]: { back: 84, lay: 89 }
            },
            fancy: {
                '6_over_runs_rr': { yes: 57, no: 55 },
                '6_over_runs_csk': { yes: 57, no: 55 },
                '10_over_runs_rr': { yes: 90, no: 88 },
                '10_over_runs_csk': { yes: 90, no: 88 }
            }
        };

        return baseOdds;
    }

    // Get upcoming matches
    async getUpcomingMatches() {
        try {
            // In production, fetch from cricket API
            // For now, return mock data
            return [
                {
                    id: 'ipl_2026_mi_vs_kkr',
                    name: 'Mumbai Indians vs Kolkata Knight Riders',
                    matchType: 't20',
                    status: 'Upcoming',
                    venue: 'Wankhede Stadium, Mumbai',
                    date: new Date(Date.now() + 86400000).toISOString(),
                    teams: ['Mumbai Indians', 'Kolkata Knight Riders']
                }
            ];
        } catch (error) {
            console.error('Error fetching upcoming matches:', error.message);
            return [];
        }
    }
}

module.exports = new CricketDataService();
