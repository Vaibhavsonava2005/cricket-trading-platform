const express = require('express');
const router = express.Router();
const cricketData = require('../services/cricketData');
const { authenticateToken } = require('../middleware/auth');

// Get live matches
router.get('/live', authenticateToken, async (req, res) => {
    try {
        const matches = await cricketData.getLiveMatches();
        
        // Add odds to each match
        const matchesWithOdds = matches.map(match => ({
            ...match,
            odds: cricketData.generateOdds(match)
        }));

        res.json({ matches: matchesWithOdds });
    } catch (error) {
        console.error('Error getting live matches:', error);
        res.status(500).json({ error: 'Failed to fetch live matches' });
    }
});

// Get upcoming matches
router.get('/upcoming', authenticateToken, async (req, res) => {
    try {
        const matches = await cricketData.getUpcomingMatches();
        res.json({ matches });
    } catch (error) {
        console.error('Error getting upcoming matches:', error);
        res.status(500).json({ error: 'Failed to fetch upcoming matches' });
    }
});

// Get match details
router.get('/:matchId', authenticateToken, async (req, res) => {
    try {
        const { matchId } = req.params;
        
        // Try to get cached data first
        let matchData = await cricketData.getCachedMatchData(matchId);
        
        if (!matchData) {
            // Fetch fresh data
            matchData = await cricketData.getMatchDetails(matchId);
            
            // Cache it
            if (matchData) {
                await cricketData.cacheMatchData(matchId, matchData);
            }
        }

        if (!matchData) {
            return res.status(404).json({ error: 'Match not found' });
        }

        // Add odds
        const odds = cricketData.generateOdds(matchData);

        res.json({ 
            match: matchData,
            odds 
        });
    } catch (error) {
        console.error('Error getting match details:', error);
        res.status(500).json({ error: 'Failed to fetch match details' });
    }
});

// Get match scorecard
router.get('/:matchId/scorecard', authenticateToken, async (req, res) => {
    try {
        const { matchId } = req.params;
        const scorecard = await cricketData.getMatchScorecard(matchId);
        
        res.json({ scorecard });
    } catch (error) {
        console.error('Error getting scorecard:', error);
        res.status(500).json({ error: 'Failed to fetch scorecard' });
    }
});

module.exports = router;
