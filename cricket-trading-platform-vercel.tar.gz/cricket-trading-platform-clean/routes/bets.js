const express = require('express');
const router = express.Router();
const db = require('../config/database');
const { authenticateToken } = require('../middleware/auth');

// Place a bet
router.post('/place', authenticateToken, async (req, res) => {
    const client = await db.pool.connect();
    
    try {
        const { matchId, matchName, betType, selection, odds, stake } = req.body;
        const userId = req.user.userId;

        // Validation
        if (!matchId || !matchName || !betType || !selection || !odds || !stake) {
            return res.status(400).json({ error: 'All bet fields are required' });
        }

        if (stake <= 0) {
            return res.status(400).json({ error: 'Stake must be greater than 0' });
        }

        await client.query('BEGIN');

        // Check user balance
        const userResult = await client.query(
            'SELECT balance FROM users WHERE id = $1',
            [userId]
        );

        const userBalance = parseFloat(userResult.rows[0].balance);

        if (userBalance < stake) {
            await client.query('ROLLBACK');
            return res.status(400).json({ error: 'Insufficient balance' });
        }

        // Calculate potential win
        const potentialWin = stake * odds;

        // Deduct stake from user balance
        await client.query(
            'UPDATE users SET balance = balance - $1 WHERE id = $2',
            [stake, userId]
        );

        // Create bet
        const betResult = await client.query(
            `INSERT INTO bets 
             (user_id, match_id, match_name, bet_type, selection, odds, stake, potential_win, status)
             VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
             RETURNING *`,
            [userId, matchId, matchName, betType, selection, odds, stake, potentialWin, 'pending']
        );

        await client.query('COMMIT');

        res.status(201).json({
            message: 'Bet placed successfully',
            bet: betResult.rows[0]
        });
    } catch (error) {
        await client.query('ROLLBACK');
        console.error('Error placing bet:', error);
        res.status(500).json({ error: 'Failed to place bet' });
    } finally {
        client.release();
    }
});

// Get user's bets
router.get('/my-bets', authenticateToken, async (req, res) => {
    try {
        const userId = req.user.userId;
        const { status } = req.query;

        let query = 'SELECT * FROM bets WHERE user_id = $1';
        const params = [userId];

        if (status) {
            query += ' AND status = $2';
            params.push(status);
        }

        query += ' ORDER BY created_at DESC';

        const result = await db.query(query, params);

        res.json({ bets: result.rows });
    } catch (error) {
        console.error('Error fetching user bets:', error);
        res.status(500).json({ error: 'Failed to fetch bets' });
    }
});

// Get bet history for a specific match
router.get('/match/:matchId', authenticateToken, async (req, res) => {
    try {
        const userId = req.user.userId;
        const { matchId } = req.params;

        const result = await db.query(
            'SELECT * FROM bets WHERE user_id = $1 AND match_id = $2 ORDER BY created_at DESC',
            [userId, matchId]
        );

        res.json({ bets: result.rows });
    } catch (error) {
        console.error('Error fetching match bets:', error);
        res.status(500).json({ error: 'Failed to fetch match bets' });
    }
});

module.exports = router;
