const express = require('express');
const router = express.Router();
const db = require('../config/database');
const { authenticateToken } = require('../middleware/auth');

// Get user balance
router.get('/balance', authenticateToken, async (req, res) => {
    try {
        const userId = req.user.userId;
        
        const result = await db.query(
            'SELECT balance FROM users WHERE id = $1',
            [userId]
        );

        res.json({ balance: result.rows[0].balance });
    } catch (error) {
        console.error('Error fetching balance:', error);
        res.status(500).json({ error: 'Failed to fetch balance' });
    }
});

// Request deposit
router.post('/deposit', authenticateToken, async (req, res) => {
    try {
        const userId = req.user.userId;
        const { amount } = req.body;

        if (!amount || amount <= 0) {
            return res.status(400).json({ error: 'Invalid amount' });
        }

        // Create deposit request
        const result = await db.query(
            `INSERT INTO deposits (user_id, amount, status, transaction_id)
             VALUES ($1, $2, $3, $4)
             RETURNING *`,
            [userId, amount, 'pending', `DEP${Date.now()}`]
        );

        res.status(201).json({
            message: 'Deposit request created. Please wait for admin approval.',
            deposit: result.rows[0]
        });
    } catch (error) {
        console.error('Error creating deposit:', error);
        res.status(500).json({ error: 'Failed to create deposit request' });
    }
});

// Request withdrawal
router.post('/withdraw', authenticateToken, async (req, res) => {
    const client = await db.pool.connect();
    
    try {
        const userId = req.user.userId;
        const { amount, bankDetails } = req.body;

        if (!amount || amount <= 0) {
            return res.status(400).json({ error: 'Invalid amount' });
        }

        await client.query('BEGIN');

        // Check balance
        const userResult = await client.query(
            'SELECT balance FROM users WHERE id = $1',
            [userId]
        );

        const balance = parseFloat(userResult.rows[0].balance);

        if (balance < amount) {
            await client.query('ROLLBACK');
            return res.status(400).json({ error: 'Insufficient balance' });
        }

        // Create withdrawal request
        const result = await client.query(
            `INSERT INTO withdrawals (user_id, amount, status, bank_details, transaction_id)
             VALUES ($1, $2, $3, $4, $5)
             RETURNING *`,
            [userId, amount, 'pending', bankDetails, `WDR${Date.now()}`]
        );

        await client.query('COMMIT');

        res.status(201).json({
            message: 'Withdrawal request created. Please wait for admin approval.',
            withdrawal: result.rows[0]
        });
    } catch (error) {
        await client.query('ROLLBACK');
        console.error('Error creating withdrawal:', error);
        res.status(500).json({ error: 'Failed to create withdrawal request' });
    } finally {
        client.release();
    }
});

// Get deposit history
router.get('/deposits', authenticateToken, async (req, res) => {
    try {
        const userId = req.user.userId;
        
        const result = await db.query(
            'SELECT * FROM deposits WHERE user_id = $1 ORDER BY created_at DESC',
            [userId]
        );

        res.json({ deposits: result.rows });
    } catch (error) {
        console.error('Error fetching deposits:', error);
        res.status(500).json({ error: 'Failed to fetch deposits' });
    }
});

// Get withdrawal history
router.get('/withdrawals', authenticateToken, async (req, res) => {
    try {
        const userId = req.user.userId;
        
        const result = await db.query(
            'SELECT * FROM withdrawals WHERE user_id = $1 ORDER BY created_at DESC',
            [userId]
        );

        res.json({ withdrawals: result.rows });
    } catch (error) {
        console.error('Error fetching withdrawals:', error);
        res.status(500).json({ error: 'Failed to fetch withdrawals' });
    }
});

// Get transaction history
router.get('/transactions', authenticateToken, async (req, res) => {
    try {
        const userId = req.user.userId;
        
        const deposits = await db.query(
            'SELECT id, amount, status, transaction_id, created_at, \'deposit\' as type FROM deposits WHERE user_id = $1',
            [userId]
        );

        const withdrawals = await db.query(
            'SELECT id, amount, status, transaction_id, created_at, \'withdrawal\' as type FROM withdrawals WHERE user_id = $1',
            [userId]
        );

        const transactions = [...deposits.rows, ...withdrawals.rows]
            .sort((a, b) => new Date(b.created_at) - new Date(a.created_at));

        res.json({ transactions });
    } catch (error) {
        console.error('Error fetching transactions:', error);
        res.status(500).json({ error: 'Failed to fetch transactions' });
    }
});

module.exports = router;
