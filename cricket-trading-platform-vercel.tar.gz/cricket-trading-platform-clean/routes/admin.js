const express = require('express');
const router = express.Router();
const db = require('../config/database');
const { authenticateToken, authenticateAdmin } = require('../middleware/auth');

// Apply admin authentication to all routes
router.use(authenticateToken);
router.use(authenticateAdmin);

// Get all users
router.get('/users', async (req, res) => {
    try {
        const result = await db.query(`
            SELECT id, username, email, balance, is_admin, created_at
            FROM users
            ORDER BY created_at DESC
        `);

        res.json({ users: result.rows });
    } catch (error) {
        console.error('Error fetching users:', error);
        res.status(500).json({ error: 'Failed to fetch users' });
    }
});

// Get user details
router.get('/users/:userId', async (req, res) => {
    try {
        const { userId } = req.params;

        const userResult = await db.query(
            'SELECT id, username, email, balance, is_admin, created_at FROM users WHERE id = $1',
            [userId]
        );

        if (userResult.rows.length === 0) {
            return res.status(404).json({ error: 'User not found' });
        }

        const betsResult = await db.query(
            'SELECT * FROM bets WHERE user_id = $1 ORDER BY created_at DESC LIMIT 10',
            [userId]
        );

        const depositsResult = await db.query(
            'SELECT * FROM deposits WHERE user_id = $1 ORDER BY created_at DESC LIMIT 10',
            [userId]
        );

        const withdrawalsResult = await db.query(
            'SELECT * FROM withdrawals WHERE user_id = $1 ORDER BY created_at DESC LIMIT 10',
            [userId]
        );

        res.json({
            user: userResult.rows[0],
            recentBets: betsResult.rows,
            recentDeposits: depositsResult.rows,
            recentWithdrawals: withdrawalsResult.rows
        });
    } catch (error) {
        console.error('Error fetching user details:', error);
        res.status(500).json({ error: 'Failed to fetch user details' });
    }
});

// Get all bets
router.get('/bets', async (req, res) => {
    try {
        const { status, limit = 50 } = req.query;

        let query = `
            SELECT b.*, u.username, u.email
            FROM bets b
            JOIN users u ON b.user_id = u.id
        `;
        const params = [];

        if (status) {
            query += ' WHERE b.status = $1';
            params.push(status);
        }

        query += ' ORDER BY b.created_at DESC LIMIT $' + (params.length + 1);
        params.push(limit);

        const result = await db.query(query, params);

        res.json({ bets: result.rows });
    } catch (error) {
        console.error('Error fetching bets:', error);
        res.status(500).json({ error: 'Failed to fetch bets' });
    }
});

// Settle a bet
router.put('/bets/:betId/settle', async (req, res) => {
    const client = await db.pool.connect();
    
    try {
        const { betId } = req.params;
        const { result: betResult } = req.body; // 'won' or 'lost'

        if (!['won', 'lost', 'void'].includes(betResult)) {
            return res.status(400).json({ error: 'Invalid bet result' });
        }

        await client.query('BEGIN');

        // Get bet details
        const bet = await client.query(
            'SELECT * FROM bets WHERE id = $1',
            [betId]
        );

        if (bet.rows.length === 0) {
            await client.query('ROLLBACK');
            return res.status(404).json({ error: 'Bet not found' });
        }

        const betData = bet.rows[0];

        if (betData.status !== 'pending') {
            await client.query('ROLLBACK');
            return res.status(400).json({ error: 'Bet already settled' });
        }

        // Update bet status
        await client.query(
            'UPDATE bets SET status = $1, result = $2, settled_at = CURRENT_TIMESTAMP WHERE id = $3',
            [betResult === 'void' ? 'void' : (betResult === 'won' ? 'won' : 'lost'), betResult, betId]
        );

        // Update user balance if won
        if (betResult === 'won') {
            await client.query(
                'UPDATE users SET balance = balance + $1 WHERE id = $2',
                [betData.potential_win, betData.user_id]
            );
        } else if (betResult === 'void') {
            // Refund stake if void
            await client.query(
                'UPDATE users SET balance = balance + $1 WHERE id = $2',
                [betData.stake, betData.user_id]
            );
        }

        // Log admin action
        await client.query(
            'INSERT INTO admin_actions (admin_id, action_type, action_details) VALUES ($1, $2, $3)',
            [req.user.userId, 'settle_bet', `Settled bet ${betId} as ${betResult}`]
        );

        await client.query('COMMIT');

        res.json({ message: 'Bet settled successfully' });
    } catch (error) {
        await client.query('ROLLBACK');
        console.error('Error settling bet:', error);
        res.status(500).json({ error: 'Failed to settle bet' });
    } finally {
        client.release();
    }
});

// Get pending deposits
router.get('/deposits/pending', async (req, res) => {
    try {
        const result = await db.query(`
            SELECT d.*, u.username, u.email
            FROM deposits d
            JOIN users u ON d.user_id = u.id
            WHERE d.status = 'pending'
            ORDER BY d.created_at DESC
        `);

        res.json({ deposits: result.rows });
    } catch (error) {
        console.error('Error fetching pending deposits:', error);
        res.status(500).json({ error: 'Failed to fetch pending deposits' });
    }
});

// Approve/Reject deposit
router.put('/deposits/:depositId/:action', async (req, res) => {
    const client = await db.pool.connect();
    
    try {
        const { depositId, action } = req.params;

        if (!['approve', 'reject'].includes(action)) {
            return res.status(400).json({ error: 'Invalid action' });
        }

        await client.query('BEGIN');

        // Get deposit details
        const deposit = await client.query(
            'SELECT * FROM deposits WHERE id = $1',
            [depositId]
        );

        if (deposit.rows.length === 0) {
            await client.query('ROLLBACK');
            return res.status(404).json({ error: 'Deposit not found' });
        }

        const depositData = deposit.rows[0];

        if (depositData.status !== 'pending') {
            await client.query('ROLLBACK');
            return res.status(400).json({ error: 'Deposit already processed' });
        }

        const newStatus = action === 'approve' ? 'approved' : 'rejected';

        // Update deposit status
        await client.query(
            'UPDATE deposits SET status = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2',
            [newStatus, depositId]
        );

        // Add balance if approved
        if (action === 'approve') {
            await client.query(
                'UPDATE users SET balance = balance + $1 WHERE id = $2',
                [depositData.amount, depositData.user_id]
            );
        }

        // Log admin action
        await client.query(
            'INSERT INTO admin_actions (admin_id, action_type, action_details) VALUES ($1, $2, $3)',
            [req.user.userId, `${action}_deposit`, `${action}d deposit ${depositId} for amount ${depositData.amount}`]
        );

        await client.query('COMMIT');

        res.json({ message: `Deposit ${action}d successfully` });
    } catch (error) {
        await client.query('ROLLBACK');
        console.error('Error processing deposit:', error);
        res.status(500).json({ error: 'Failed to process deposit' });
    } finally {
        client.release();
    }
});

// Get pending withdrawals
router.get('/withdrawals/pending', async (req, res) => {
    try {
        const result = await db.query(`
            SELECT w.*, u.username, u.email
            FROM withdrawals w
            JOIN users u ON w.user_id = u.id
            WHERE w.status = 'pending'
            ORDER BY w.created_at DESC
        `);

        res.json({ withdrawals: result.rows });
    } catch (error) {
        console.error('Error fetching pending withdrawals:', error);
        res.status(500).json({ error: 'Failed to fetch pending withdrawals' });
    }
});

// Approve/Reject withdrawal
router.put('/withdrawals/:withdrawalId/:action', async (req, res) => {
    const client = await db.pool.connect();
    
    try {
        const { withdrawalId, action } = req.params;

        if (!['approve', 'reject'].includes(action)) {
            return res.status(400).json({ error: 'Invalid action' });
        }

        await client.query('BEGIN');

        // Get withdrawal details
        const withdrawal = await client.query(
            'SELECT * FROM withdrawals WHERE id = $1',
            [withdrawalId]
        );

        if (withdrawal.rows.length === 0) {
            await client.query('ROLLBACK');
            return res.status(404).json({ error: 'Withdrawal not found' });
        }

        const withdrawalData = withdrawal.rows[0];

        if (withdrawalData.status !== 'pending') {
            await client.query('ROLLBACK');
            return res.status(400).json({ error: 'Withdrawal already processed' });
        }

        const newStatus = action === 'approve' ? 'approved' : 'rejected';

        // Update withdrawal status
        await client.query(
            'UPDATE withdrawals SET status = $1, updated_at = CURRENT_TIMESTAMP WHERE id = $2',
            [newStatus, withdrawalId]
        );

        // Deduct balance if approved
        if (action === 'approve') {
            await client.query(
                'UPDATE users SET balance = balance - $1 WHERE id = $2',
                [withdrawalData.amount, withdrawalData.user_id]
            );
        }

        // Log admin action
        await client.query(
            'INSERT INTO admin_actions (admin_id, action_type, action_details) VALUES ($1, $2, $3)',
            [req.user.userId, `${action}_withdrawal`, `${action}d withdrawal ${withdrawalId} for amount ${withdrawalData.amount}`]
        );

        await client.query('COMMIT');

        res.json({ message: `Withdrawal ${action}d successfully` });
    } catch (error) {
        await client.query('ROLLBACK');
        console.error('Error processing withdrawal:', error);
        res.status(500).json({ error: 'Failed to process withdrawal' });
    } finally {
        client.release();
    }
});

// Get dashboard stats
router.get('/stats', async (req, res) => {
    try {
        const totalUsers = await db.query('SELECT COUNT(*) FROM users WHERE is_admin = false');
        const totalBets = await db.query('SELECT COUNT(*) FROM bets');
        const pendingDeposits = await db.query('SELECT COUNT(*) FROM deposits WHERE status = \'pending\'');
        const pendingWithdrawals = await db.query('SELECT COUNT(*) FROM withdrawals WHERE status = \'pending\'');
        const totalRevenue = await db.query('SELECT SUM(stake) FROM bets WHERE status = \'lost\'');

        res.json({
            stats: {
                totalUsers: parseInt(totalUsers.rows[0].count),
                totalBets: parseInt(totalBets.rows[0].count),
                pendingDeposits: parseInt(pendingDeposits.rows[0].count),
                pendingWithdrawals: parseInt(pendingWithdrawals.rows[0].count),
                totalRevenue: parseFloat(totalRevenue.rows[0].sum || 0)
            }
        });
    } catch (error) {
        console.error('Error fetching stats:', error);
        res.status(500).json({ error: 'Failed to fetch stats' });
    }
});

module.exports = router;
