const { Pool } = require('pg');
require('dotenv').config();

const pool = new Pool({
    connectionString: process.env.DATABASE_URL,
    ssl: {
        rejectUnauthorized: false
    }
});

pool.on('connect', () => {
    console.log('✅ Database connected successfully');
});

pool.on('error', (err) => {
    console.error('❌ Unexpected error on idle client', err);
    process.exit(-1);
});

// Initialize database tables
const initializeDatabase = async () => {
    const fs = require('fs');
    const path = require('path');
    
    try {
        const schema = fs.readFileSync(path.join(__dirname, '../schema.sql'), 'utf8');
        await pool.query(schema);
        console.log('✅ Database schema initialized');
        
        // Create default admin user if not exists
        const bcrypt = require('bcryptjs');
        const hashedPassword = await bcrypt.hash('admin123', 10);
        
        await pool.query(`
            INSERT INTO users (username, email, password, is_admin, balance)
            VALUES ($1, $2, $3, $4, $5)
            ON CONFLICT (email) DO NOTHING
        `, ['admin', 'admin@crickettrading.com', hashedPassword, true, 10000.00]);
        
        console.log('✅ Default admin user created (email: admin@crickettrading.com, password: admin123)');
    } catch (error) {
        console.error('❌ Error initializing database:', error);
        throw error;
    }
};

module.exports = {
    pool,
    initializeDatabase,
    query: (text, params) => pool.query(text, params)
};
